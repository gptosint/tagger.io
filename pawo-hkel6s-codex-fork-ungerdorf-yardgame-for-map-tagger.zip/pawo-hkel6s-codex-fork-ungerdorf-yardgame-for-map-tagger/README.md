# Map Tagger

A minimal web application for placing text tags on an interactive map.
The frontend uses [Leaflet](https://leafletjs.com/) and the backend is a
simple Node.js server that stores tags in a JSON file.

## Setup

Install Node.js dependencies and start the backend:

```bash
./install.sh
# or manually:
# npm install express body-parser
node backend.js
```

The server listens on `http://localhost:3000/` and serves `index.html`.

## Usage

1. Open `http://localhost:3000/` in your browser.
2. Click anywhere on the map and enter a description for the tag.
3. Existing tags are loaded on page load. Use the **Clear Tags** button to
   remove all tags.

Tags are persisted in `tags.json` in the project directory.
